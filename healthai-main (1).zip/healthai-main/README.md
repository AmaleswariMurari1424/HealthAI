# HealthAI: Intelligent Healthcare Assistant Using IBM Granite
